import { Product } from "../products/product";

export const CART_PRODUCTS:Product[] = [];