#!c:\users\аскар\desktop\webdevelopment\wd2020\final-project\env-back\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
